<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    protected $product;

    public function index()
    {
        return view("product.add2");
    }

    public function js()
    {
        return view("js.js");
    }

    public function calculator()
    {
        return view('calculator');
    }

    public function newProduct(Request $request)
    {
        Product::SaveData($request);
        return redirect()->back()->with('message','success');
    }
    public function manageProduct()
    {
        //return Product::all();               //return Product::latest()->get();
                                               //return Product::orderBy('id','DESC');
        //                                    //return Product::where(status,1)->get();
                                                //return Product::where('status',0)->first();
        return view('product.manage' , [
            'products' =>Product::all(),
        ]);
    }
    public function deleteProduct($productId)
    {

        $this->product = Product::findOrFail($productId);
        if(file_exists($this->product->product_image))
        {
            unlink($this->product->product_image);
        }
        $this->product->delete();
        return redirect()->back()->with('message','delete successfully');

    }
    public function productStatus($productId)
    {
        $this->product = Product::findOrFail($productId);
        $this->product->status = $this->product->status == 1 ? 0 : 1;
        $this->product->save();
        return redirect()->back()->with('message', 'status changed successfully');

    }
    public function productEdit($productId)
    {
        return view('product.productEdit' , [
            'product' => Product::findOrFail($productId)
        ]);
    }
    public function updateProduct(Request $request)
    {
        Product::updateData($request);
        return redirect('manage-product')->with('message','Product updated successfully');

    }
}

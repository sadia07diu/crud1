<?php $__env->startSection('title'); ?>
    Edit product

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h4>Update product</h4>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('update-product')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden"  name="product_id" value="<?php echo e($product->id); ?>">
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Product Name</label>
                                    <div class="col-md-8">
                                        <input type="text" name="product_name" class="form-control" value="<?php echo e($product->product_name); ?>" />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Category Name</label>
                                    <div class="col-md-8">
                                        <input type="text" name="category_name" class="form-control" value="<?php echo e($product->category_name); ?>"/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Brand Name</label>
                                    <div class="col-md-8">
                                        <input type="text" name="brand_name" class="form-control" value="<?php echo e($product->brand_name); ?>"/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Product Price</label>
                                    <div class="col-md-8">
                                        <input type="number" name="product_price" class="form-control" value="<?php echo e($product->product_price); ?>"/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Product Image</label>
                                    <div class="col-md-8">
                                        <input type="file" name="product_image" class="form-control" />
                                        <img src="<?php echo e(asset($product->product_image)); ?>"  alt="" style="width: 100px; height: 100px;">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Product description</label>
                                    <div class="col-md-8">
                                        <textarea type="text" name="product_description" id="" cols="30" rows="2" class="form-control" ><?php echo e($product-> product_description); ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Product Status</label>
                                    <div class="col-md-8">
                                        <label for="" ><input type="radio" name="status" <?php echo e($product->status == 1 ? 'checked' : ''); ?> value="1"/>Published</label>
                                        <label for="" ><input type="radio" name="status" <?php echo e($product->status == 0 ? 'checked' : ''); ?> value="0"/>Unpublished</label>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <input type="submit" value="Update Product" class="btn btn-success btn-block" />

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fourth_project\resources\views/product/productEdit.blade.php ENDPATH**/ ?>
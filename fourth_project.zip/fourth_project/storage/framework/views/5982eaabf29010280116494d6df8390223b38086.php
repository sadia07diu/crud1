
<style>
    .small-image{
        height: 100px;
        width: 100px;
    }
</style>

<div class="ml-4" style="height: 400px;width: 600px;">

    <img src="<?php echo e(asset('assets/img/d3.jpeg')); ?>" id="box1" alt="" class="img-fluid h-100"/>
</div>

<div class="ml-4 mt-2">
    <img src="<?php echo e(asset('assets/img/d3.jpeg')); ?>" alt="" onclick="changeImg('d3')" class="small-image mr-2" id="smallImage1">
    <img src="<?php echo e(asset('assets/img/d4.jpg')); ?>" alt="" onclick="changeImg('d4')" class="small-image mr-2" id="smallImage2">
    <img src="<?php echo e(asset('assets/img/s1.jpg')); ?>" alt="" onclick="changeImg('s1')" class="small-image mr-2" id="smallImage3">
    <img src="<?php echo e(asset('assets/img/s2.jpg')); ?>" alt="" onclick="changeImg('s2')" class="small-image mr-2" id="smallImage4">
</div>

<script>

    var smallImage1 = document.getElementById('smallImage1')
    smallImage1.onclick = function () {
        var div = document.getElementById("box1");
        var imgUrl = smallImage1.getAttribute('src')
        div.setAttribute('src', imgUrl);
    }
    var smallImage2 = document.getElementById('smallImage2')
    smallImage2.onclick = function () {
        var div = document.getElementById("box1");
        div.setAttribute('src', 'assets/img/d4.jpg');
    }
    var smallImage3 = document.getElementById('smallImage3')
    smallImage3.onclick = function () {
        var div = document.getElementById("box1");
        div.setAttribute('src', 'assets/img/s1.jpg');
    }
    var smallImage4 = document.getElementById('smallImage4')
    smallImage4.onclick = function () {
        var div = document.getElementById("box1");
        div.setAttribute('src', 'assets/img/s2.jpg');
    }

    function changeImg(filePath) {
        var div = document.getElementById("box1");
        div.setAttribute('src', `assets/img/${filePath}.jpg`);
    }

</script>
<?php /**PATH C:\xampp\htdocs\fourth_project\resources\views/includes/image-change.blade.php ENDPATH**/ ?>
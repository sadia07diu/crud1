@extends('master')

@section('title')
    Manage product
@endsection
@section('body')
    <section class="py-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Manage product</h4>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Brand name</th>
                                    <th>Product price</th>
                                    <th>Product Image</th>
                                    <th>Product description</th>
                                    <th>Product status</th>
                                    <th>Action</th>

                                </tr>
                                </thead>
                                <tbody>
                                @foreach($products as $product)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $product->product_name }}</td>
                                    <td>{{ $product->category_name }}</td>
                                    <td>{{ $product->brand_name }}</td>
                                    <td>{{ $product->product_price }}</td>
                                    <td>
                                        <img src="{{ $product->product_image }}" alt=""  style="width: 100px; height:100px" >
                                    </td>
                                    <td>{{ $product->product_description }}</td>
                                    <td>{{ $product->status ==1  ? 'Published' : 'Unpublished' }}</td>
                                    <td>
                                        <a href="{{ route('product-status',['productId'=>$product->id]) }}" class="btn btn-{{ $product->status ==1 ? 'primary' : 'secondary' }}  btn-sm" value="Delete">Status</a>
                                        <a href="{{ route('product-edit',['productId'=>$product->id]) }}" class="btn btn-{{ $product->status ==1 ? 'info' : 'warning' }}  btn-sm" >Edit</a>
                                        <a href="{{ route('delete-product',['productId'=>$product->id]) }}" class="btn btn-danger  btn-sm" onclick="event.preventDefault(); confirm('Are you sure to delete this ?')" value="Delete"><i class="fa-solid fa-trash"></i></a>
                                    </td>

                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@extends('master')

@section('title')
    form
@endsection
@section('body')
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header text-center">Registration</div>
                    <div class="card-body">
                        <form action="" method="post">
                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">First Name</label>
                                <div class="col-md-9">
                                    <input type="text"  class="form-control" id="firstName"/>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Last Name</label>
                                <div class="col-md-9">
                                    <input type="text"  class="form-control" id="lastName"/>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Full name</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" id="fullName"/>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label"></label>
                                <div class="col-md-9">
                                    <input type="button" class="btn btn-success " onclick="makeFullName()"  value="Submit"/>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection

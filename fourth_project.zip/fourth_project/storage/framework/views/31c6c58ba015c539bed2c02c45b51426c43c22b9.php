

<h1 id ='headingTag' class="text-center"> hello World</h1>
<div class="py-5">
    <ul class="nav">
        <li class="nav-item">
            <a href="javascript:void(0) " id ='colorRed' class=" btn btn-danger nav-link">Red</a>
        </li>
        <li class="nav-item">
            <a href="" id ='colorGreen' class="btn btn-success nav-link">Green</a>
        </li>
        <li class="nav-item">
            <a href="" id ='colorGrey' class="btn btn-secondary nav-link">Grey</a>
        </li>
        <li class="nav-item">
            <a href="" id ='colorBlack' class="btn btn-dark nav-link">Black</a>
        </li>
    </ul>
    <div id="div" class="mt-3" style=" height: 300px;width: 300px;border: 1px solid orange;"></div>
</div>

<script>
    var btnRed = document.getElementById('colorRed')
    btnRed.onclick = function () {
        event.preventDefault();

        var box = document.getElementById('div');
        box.style.backgroundColor = 'red';
    }

    var btnGreen = document.getElementById('colorGreen')
    btnGreen.onclick = function () {
        event.preventDefault();

        var box = document.getElementById('div');
        box.style.backgroundColor = 'green';
    }

    var btnGrey = document.getElementById('colorGrey')
    btnGrey.onclick = function () {
        event.preventDefault();

        var box = document.getElementById('div');
        box.style.backgroundColor = 'grey';
    }
    var btnBlack = document.getElementById('colorBlack')
    btnBlack.onclick = function () {
        event.preventDefault();

        var box = document.getElementById('div');
        box.style.backgroundColor = 'black';
    }


    // colorGreen.onclick= function () {
    //     div.style.backgroundColor = 'green';
    // }
    // colorGrey.onclick = function () {
    //     div.style.backgroundColor= 'red';
    // }
    // colorBlack.onclick= function () {
    //     div.style.backgroundColor = 'green';
    // }

</script>

<script>
    var heading = document.getElementById("headingTag");
    var div = document.getElementById("div");

    // console.log(heading);

    heading.onclick = function () {
        // heading.innerText = 'hello Bitm'
        heading.innerHTML = 'hello Bitm';
        heading.style.color = 'green';
    }

    heading.onmouseover = function () {
        heading.style.color = 'red';
    }

    heading.onmouseleave = function () {
        heading.style.color = 'black';
    }



</script>

<?php /**PATH C:\xampp\htdocs\fourth_project\resources\views/includes/color-change.blade.php ENDPATH**/ ?>